rootProject.name = "ServerMineEconomy"
include("economy-api", "economy-plugin")
