plugins {
    java
}

dependencies {
    implementation(project(":economy-api"))
    compileOnly("org.purpurmc.purpur:purpur-api:26.2.build.+")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(25)
}

tasks.processResources {
    filteringCharset = "UTF-8"
    filesMatching("plugin.yml") {
        expand("version" to project.version)
    }
}

// Economy API классы входят в основной plugin JAR, чтобы dependent-плагины
// получали их через declared depend и Bukkit ServicesManager.
tasks.jar {
    archiveBaseName.set("ServerMineEconomy")
    from(project(":economy-api").sourceSets.main.get().output)
}
