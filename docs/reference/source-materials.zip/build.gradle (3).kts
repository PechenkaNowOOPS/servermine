plugins {
    java
}

group = "ru.servermine"
version = "0.1.0-SNAPSHOT"

repositories {
    maven("https://repo.purpurmc.org/snapshots")
    mavenCentral()
}

dependencies {
    compileOnly("org.purpurmc.purpur:purpur-api:26.2.build.+")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(25)
}

tasks.processResources {
    filteringCharset = "UTF-8"
}
