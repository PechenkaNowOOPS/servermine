repositories {
    maven("https://repo.purpurmc.org/snapshots")
}

dependencies {
    compileOnly("org.purpurmc.purpur:purpur-api:26.2.build.+")
    compileOnly(files("libs/servermine-economy-api-0.1.0-SNAPSHOT.jar"))
}
