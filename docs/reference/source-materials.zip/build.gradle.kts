plugins {
    base
}

allprojects {
    group = "ru.servermine"
    version = "0.1.0-SNAPSHOT"

    repositories {
        mavenCentral()
        maven("https://repo.purpurmc.org/snapshots")
    }
}
